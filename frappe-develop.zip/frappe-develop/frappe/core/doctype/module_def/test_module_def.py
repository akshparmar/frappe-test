# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# License: MIT. See LICENSE
from frappe.tests.utils import FrappeTestCase

# test_records = frappe.get_test_records('Module Def')


class TestModuleDef(FrappeTestCase):
	pass
