frappe.listview_settings["Document Naming Rule"] = {
	hide_name_column: true,
};
